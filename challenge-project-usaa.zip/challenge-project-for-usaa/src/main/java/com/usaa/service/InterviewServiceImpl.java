package com.usaa.service;

import com.usaa.Challenge;

import java.util.ArrayList;
import java.util.List;

public class InterviewServiceImpl implements InterviewService {
    @Override
    public List<Challenge> getInterview(String id) {
        return  new ArrayList<>();
    }
}
